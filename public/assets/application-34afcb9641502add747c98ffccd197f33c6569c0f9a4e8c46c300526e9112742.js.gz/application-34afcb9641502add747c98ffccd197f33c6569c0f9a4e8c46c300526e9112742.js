import "@hotwired/turbo-rails"
import "controllers"
import "jquery"
import "bootstrap";
